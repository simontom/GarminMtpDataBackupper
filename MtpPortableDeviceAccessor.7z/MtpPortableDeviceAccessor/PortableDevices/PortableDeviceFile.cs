﻿namespace PortableDevices
{
    public class PortableDeviceFile : PortableDeviceObject
    {
        public PortableDeviceFile(string id, string name) : base(id, name)
        {        
        }
    }
}